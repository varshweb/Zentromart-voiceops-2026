"""Evaluation script for Step 1 (Prompted Baseline) vs Step 2 (Grounded RAG).

Runs benchmark across all 52 questions in practice/questions.csv,
scoring decisions, retrieval quality, must_include coverage, and hallucinations.
Outputs a detailed JSON report and summary statistics table.
"""

import os
import sys
import json
import re
import importlib.util
from typing import Dict, Any, List, Tuple
import pandas as pd

_SRC_DIR = os.path.abspath(os.path.dirname(__file__))

def _load_module(name: str, rel_path: str):
    if name not in sys.modules:
        path = os.path.join(_SRC_DIR, rel_path)
        spec = importlib.util.spec_from_file_location(name, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[name] = mod
        spec.loader.exec_module(mod)
    return sys.modules[name]

_load_module('kb_indexer', 'kb_indexer.py')
_load_module('retriever', 'retriever.py')
_load_module('llm', 'llm.py')

from retriever import KBRetriever
from llm import LLMClient

def evaluate_must_include(reply: str, must_include_str: str) -> bool:
    if not must_include_str or str(must_include_str) == 'nan' or not must_include_str.strip():
        return True
    
    reply_lower = reply.lower()
    groups = [g.strip() for g in must_include_str.split(';') if g.strip()]
    for grp in groups:
        alternatives = [alt.strip().lower() for alt in grp.split('/') if alt.strip()]
        matched = any(alt in reply_lower for alt in alternatives)
        if not matched:
            return False
    return True

def evaluate_must_not_include(reply: str, must_not_include_str: str) -> Tuple[bool, List[str]]:
    if not must_not_include_str or str(must_not_include_str) == 'nan' or not must_not_include_str.strip():
        return True, []
        
    reply_lower = reply.lower()
    forbidden = [f.strip().lower() for f in must_not_include_str.split(';') if f.strip()]
    violations = [f for f in forbidden if f in reply_lower]
    return len(violations) == 0, violations

def run_evaluation(
    questions_csv: str,
    kb_dir: str,
    products_csv: str,
    output_json: str = "sample_outputs/step1_vs_step2_eval.json"
):
    df = pd.read_csv(questions_csv, dtype=str)
    retriever = KBRetriever(kb_dir=kb_dir, products_csv_path=products_csv)
    llm = LLMClient()
    
    results = []
    
    s1_dec_correct = 0
    s1_must_inc_hits = 0
    s1_must_not_inc_violations = 0
    s1_unanswerable_handled = 0
    
    s2_dec_correct = 0
    s2_must_inc_hits = 0
    s2_must_not_inc_violations = 0
    s2_retrieval_hits = 0
    s2_hard_neg_violations = 0
    s2_unanswerable_handled = 0
    
    total_q = len(df)
    total_answerable = 0
    total_unanswerable = 0
    
    for idx, r in df.iterrows():
        qid = r['id']
        question = r['question']
        exp_dec = r['expected_decision']
        acc_decs = [d.strip() for d in str(r.get('acceptable_decisions', exp_dec)).split(';') if d.strip()]
        if exp_dec not in acc_decs:
            acc_decs.append(exp_dec)
            
        is_answerable = r['answerable'] == 'True'
        if is_answerable:
            total_answerable += 1
        else:
            total_unanswerable += 1
            
        gold_str = str(r['gold_evidence'])
        gold_items = [g.strip() for g in gold_str.split(';') if g.strip() and g.strip() != 'nan']
        
        hard_neg_str = str(r['hard_negatives'])
        hard_negs = [n.strip() for n in hard_neg_str.split(';') if n.strip() and n.strip() != 'nan']
        
        must_inc = str(r['must_include'])
        must_not_inc = str(r['must_not_include'])
        
        # --- Run Step 1: Prompted Baseline ---
        out_s1 = llm.generate_step1(question)
        s1_reply = out_s1['reply']
        s1_dec = out_s1['decision']
        
        s1_dec_ok = s1_dec in acc_decs
        if s1_dec_ok:
            s1_dec_correct += 1
            
        s1_inc_ok = evaluate_must_include(s1_reply, must_inc)
        if s1_inc_ok:
            s1_must_inc_hits += 1
            
        s1_not_inc_ok, s1_viols = evaluate_must_not_include(s1_reply, must_not_inc)
        if not s1_not_inc_ok:
            s1_must_not_inc_violations += 1
            
        if not is_answerable:
            if any(phrase in s1_reply.lower() for phrase in ["don't know", "do not offer", "not covered"]):
                s1_unanswerable_handled += 1
                
        # --- Run Step 2: Grounded RAG ---
        retrieved_chunks = retriever.search(question, top_k=5)
        retrieved_sec_ids = [c['sec_id'] for c in retrieved_chunks]
        
        ret_ok = any(g in retrieved_sec_ids for g in gold_items) if gold_items else True
        if is_answerable and ret_ok:
            s2_retrieval_hits += 1
            
        hard_neg_ok = not any(n in retrieved_sec_ids for n in hard_negs)
        if not hard_neg_ok:
            s2_hard_neg_violations += 1
            
        out_s2 = llm.generate_step2(question, retrieved_chunks)
        s2_reply = out_s2['reply']
        s2_dec = out_s2['decision']
        s2_citations = out_s2['citations']
        
        s2_dec_ok = s2_dec in acc_decs
        if s2_dec_ok:
            s2_dec_correct += 1
            
        s2_inc_ok = evaluate_must_include(s2_reply, must_inc)
        if s2_inc_ok:
            s2_must_inc_hits += 1
            
        s2_not_inc_ok, s2_viols = evaluate_must_not_include(s2_reply, must_not_inc)
        if not s2_not_inc_ok:
            s2_must_not_inc_violations += 1
            
        if not is_answerable:
            if any(phrase in s2_reply.lower() for phrase in ["do not currently cover", "don't have information", "not covered", "human agent"]):
                s2_unanswerable_handled += 1

        results.append({
            'id': qid,
            'question': question,
            'expected_decision': exp_dec,
            'answerable': is_answerable,
            'gold_evidence': gold_items,
            'step1': {
                'decision': s1_dec,
                'decision_correct': s1_dec_ok,
                'reply': s1_reply,
                'must_include_passed': s1_inc_ok,
                'must_not_include_violations': s1_viols,
            },
            'step2': {
                'decision': s2_dec,
                'decision_correct': s2_dec_ok,
                'retrieved_sections': retrieved_sec_ids,
                'retrieval_passed': ret_ok,
                'hard_negative_passed': hard_neg_ok,
                'reply': s2_reply,
                'citations': s2_citations,
                'must_include_passed': s2_inc_ok,
                'must_not_include_violations': s2_viols,
            }
        })
        
    summary = {
        'total_questions': total_q,
        'total_answerable': total_answerable,
        'total_unanswerable': total_unanswerable,
        'step1_baseline': {
            'decision_accuracy': f"{s1_dec_correct}/{total_q} ({s1_dec_correct/total_q*100:.1f}%)",
            'must_include_accuracy': f"{s1_must_inc_hits}/{total_q} ({s1_must_inc_hits/total_q*100:.1f}%)",
            'hallucination_violations': s1_must_not_inc_violations,
            'unanswerable_handled': f"{s1_unanswerable_handled}/{total_unanswerable}"
        },
        'step2_grounded_rag': {
            'decision_accuracy': f"{s2_dec_correct}/{total_q} ({s2_dec_correct/total_q*100:.1f}%)",
            'retrieval_recall': f"{s2_retrieval_hits}/{total_answerable} ({s2_retrieval_hits/total_answerable*100:.1f}%)",
            'hard_negative_violations': s2_hard_neg_violations,
            'must_include_accuracy': f"{s2_must_inc_hits}/{total_q} ({s2_must_inc_hits/total_q*100:.1f}%)",
            'hallucination_violations': s2_must_not_inc_violations,
            'unanswerable_handled': f"{s2_unanswerable_handled}/{total_unanswerable}"
        }
    }
    
    os.makedirs(os.path.dirname(output_json), exist_ok=True)
    with open(output_json, 'w', encoding='utf-8') as f:
        json.dump({'summary': summary, 'results': results}, f, indent=2, ensure_ascii=False)
        
    print("=" * 65)
    print("VOICEOPS 2026: STEP 1 (BASELINE) vs STEP 2 (RAG) EVALUATION")
    print("=" * 65)
    print(f"Total Questions Evaluated: {total_q} (Answerable: {total_answerable}, Unanswerable: {total_unanswerable})")
    print("\nMETRIC                           | STEP 1 (BASELINE) | STEP 2 (RAG)")
    print("-" * 65)
    print(f"Decision Accuracy                | {summary['step1_baseline']['decision_accuracy']:<17} | {summary['step2_grounded_rag']['decision_accuracy']}")
    print(f"Retrieval Recall (Gold Evidence) | {'N/A (No KB)':<17} | {summary['step2_grounded_rag']['retrieval_recall']}")
    print(f"Hard Negative Violations         | {'N/A':<17} | {summary['step2_grounded_rag']['hard_negative_violations']}")
    print(f"Key Fact Precision (must_include)| {summary['step1_baseline']['must_include_accuracy']:<17} | {summary['step2_grounded_rag']['must_include_accuracy']}")
    print(f"Hallucination Violations         | {str(summary['step1_baseline']['hallucination_violations']):<17} | {summary['step2_grounded_rag']['hallucination_violations']}")
    print(f"Unanswerable / 'I don't know'    | {summary['step1_baseline']['unanswerable_handled']:<17} | {summary['step2_grounded_rag']['unanswerable_handled']}")
    print("=" * 65)
    print(f"Full per-question results saved to: {output_json}")

if __name__ == '__main__':
    run_evaluation(
        questions_csv='Capstone_Project_Dataset_FTTT_2026/practice/questions.csv',
        kb_dir='Capstone_Project_Dataset_FTTT_2026/kb',
        products_csv='Capstone_Project_Dataset_FTTT_2026/data/products.csv'
    )
