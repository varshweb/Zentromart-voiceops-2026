"""Knowledge Base Indexer and Chunker for ZentroMart Capstone.

Parses all 21 Markdown files in kb/ and products in data/products.csv,
preserving [SECTION-ID] tags, metadata, precedence, and versioning.
"""

import os
import re
import glob
import csv
import sqlite3
from typing import List, Dict, Any, Optional

# Precedence ranking per KB-00.1:
# 1. Policy (current) -> rank 10
# 2. Agent guides -> rank 8
# 3. Help articles -> rank 6
# 4. FAQs -> rank 4
# 5. Marketing -> rank 2
# Superseded docs -> rank 1
DOC_TYPE_RANKS = {
    'policy': 10,
    'agent_guide': 8,
    'help': 6,
    'faq': 4,
    'marketing': 2,
    'meta': 1,
}

class KBChunk:
    def __init__(
        self,
        chunk_id: str,
        sec_id: str,
        doc_id: str,
        doc_type: str,
        title: str,
        sec_title: str,
        content: str,
        effective_from: str,
        status: str,
        superseded_by: str,
        file_name: str,
        language: str = 'en',
        is_product: bool = False,
        sku: str = ''
    ):
        self.chunk_id = chunk_id
        self.sec_id = sec_id
        self.doc_id = doc_id
        self.doc_type = doc_type
        self.title = title
        self.sec_title = sec_title
        self.content = content
        self.effective_from = effective_from
        self.status = status
        self.superseded_by = superseded_by
        self.file_name = file_name
        self.language = language
        self.is_product = is_product
        self.sku = sku
        
        # Calculate base precedence score
        base_rank = DOC_TYPE_RANKS.get(doc_type, 3)
        if status == 'superseded':
            base_rank = 1
        self.base_rank = base_rank

    def to_dict(self) -> Dict[str, Any]:
        return {
            'chunk_id': self.chunk_id,
            'sec_id': self.sec_id,
            'doc_id': self.doc_id,
            'doc_type': self.doc_type,
            'title': self.title,
            'sec_title': self.sec_title,
            'content': self.content,
            'effective_from': self.effective_from,
            'status': self.status,
            'superseded_by': self.superseded_by,
            'file_name': self.file_name,
            'language': self.language,
            'is_product': self.is_product,
            'sku': self.sku,
            'base_rank': self.base_rank
        }


def parse_frontmatter(text: str) -> tuple[Dict[str, str], str]:
    fm = {}
    body = text
    if text.startswith('---'):
        parts = text.split('---', 2)
        if len(parts) >= 3:
            fm_text = parts[1]
            body = parts[2]
            for line in fm_text.strip().splitlines():
                if ':' in line:
                    k, v = line.split(':', 1)
                    fm[k.strip()] = v.strip()
    return fm, body


def load_kb_chunks(kb_dir: str) -> List[KBChunk]:
    chunks = []
    kb_files = sorted(glob.glob(os.path.join(kb_dir, '*.md')))
    
    for path in kb_files:
        with open(path, 'r', encoding='utf-8') as f:
            raw_text = f.read()
        
        fm, body = parse_frontmatter(raw_text)
        doc_id = fm.get('doc_id', '')
        doc_type = fm.get('doc_type', '')
        doc_title = fm.get('title', '')
        effective_from = fm.get('effective_from', '')
        status = fm.get('status', 'current')
        superseded_by = fm.get('superseded_by', '')
        language = fm.get('language', 'en')
        file_name = os.path.basename(path)
        
        # Split by ## [SECTION_ID]
        splits = re.split(r'(^##\s*\[[^\]]+\][^\n]*)', body, flags=re.MULTILINE)
        
        # If there is introductory preamble text before first section, record it if substantive
        preamble = splits[0].strip()
        # Remove top level # Title
        preamble = re.sub(r'^#\s+[^\n]*', '', preamble).strip()
        if preamble and len(preamble) > 30 and not splits[1:]:
            # Document has no ## sections (rare, but keep safe)
            chunks.append(KBChunk(
                chunk_id=f"{doc_id}_main",
                sec_id=doc_id,
                doc_id=doc_id,
                doc_type=doc_type,
                title=doc_title,
                sec_title=doc_title,
                content=preamble,
                effective_from=effective_from,
                status=status,
                superseded_by=superseded_by,
                file_name=file_name,
                language=language
            ))

        for i in range(1, len(splits), 2):
            sec_header = splits[i].strip()
            sec_body = splits[i + 1].strip() if i + 1 < len(splits) else ''
            
            m = re.match(r'^##\s*\[([^\]]+)\]\s*(.*)', sec_header)
            if m:
                sec_id = m.group(1).strip()
                sec_title = m.group(2).strip()
                # Include section header info in searchable content
                full_content = f"{doc_title} - {sec_title}\n\n{sec_body}".strip()
                
                chunks.append(KBChunk(
                    chunk_id=sec_id,
                    sec_id=sec_id,
                    doc_id=doc_id,
                    doc_type=doc_type,
                    title=doc_title,
                    sec_title=sec_title,
                    content=full_content,
                    effective_from=effective_from,
                    status=status,
                    superseded_by=superseded_by,
                    file_name=file_name,
                    language=language
                ))
                
    return chunks


def load_product_chunks(products_csv_path: str) -> List[KBChunk]:
    chunks = []
    if not os.path.exists(products_csv_path):
        return chunks
        
    with open(products_csv_path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            sku = row['sku']
            title = row['title']
            brand = row.get('brand', '')
            category = row.get('return_category', '')
            price = row.get('price_inr', '')
            fulfilled = row.get('fulfilled_by', '')
            assured = row.get('assured', '')
            warranty = row.get('warranty_months', '')
            desc = row.get('description', '')
            
            text = (
                f"Product SKU: {sku}\n"
                f"Title: {title}\n"
                f"Brand: {brand}\n"
                f"Category: {category}\n"
                f"Price: ₹{price}\n"
                f"Fulfilled by: {fulfilled}\n"
                f"ZentroMart Assured: {assured}\n"
                f"Warranty: {warranty} months\n"
                f"Description: {desc}"
            )
            
            chunks.append(KBChunk(
                chunk_id=f"products.csv:{sku}",
                sec_id=f"products.csv:{sku}",
                doc_id="products.csv",
                doc_type="catalog",
                title=f"Product: {title} ({sku})",
                sec_title=title,
                content=text,
                effective_from="2026-01-01",
                status="current",
                superseded_by="",
                file_name="products.csv",
                is_product=True,
                sku=sku
            ))
            
    return chunks
