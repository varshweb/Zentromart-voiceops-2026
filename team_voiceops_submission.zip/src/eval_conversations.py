"""Evaluation harness for Step 3: Multi-turn Conversations.

Benchmarks the conversational agent against all 96 turns across 23 conversations
in practice/conversations.csv, checking:
1. Decision accuracy (clarify, answer, refuse, escalate)
2. Tool call correctness (lookup_order unverified, lookup_order verified, create_ticket)
3. Key fact coverage (must_include)
4. Hallucination prevention (must_not_include)
"""

import os
import sys
import json
import importlib.util
import pandas as pd
from typing import Dict, Any, List, Tuple

_SRC_DIR = os.path.abspath(os.path.dirname(__file__))

def _load_module(name: str, rel_path: str):
    if name not in sys.modules:
        path = os.path.join(_SRC_DIR, rel_path)
        spec = importlib.util.spec_from_file_location(name, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[name] = mod
        spec.loader.exec_module(mod)
    return sys.modules[name]

_load_module('agent', 'agent.py')
from agent import SupportAgent

def evaluate_must_include(reply: str, must_include_str: str) -> bool:
    if not must_include_str or str(must_include_str) == 'nan' or not must_include_str.strip():
        return True
    
    reply_lower = reply.lower()
    groups = [g.strip() for g in must_include_str.split(';') if g.strip()]
    for grp in groups:
        alternatives = [alt.strip().lower() for alt in grp.split('/') if alt.strip()]
        matched = any(alt in reply_lower for alt in alternatives)
        if not matched:
            return False
    return True

def evaluate_must_not_include(reply: str, must_not_include_str: str) -> Tuple[bool, List[str]]:
    if not must_not_include_str or str(must_not_include_str) == 'nan' or not must_not_include_str.strip():
        return True, []
        
    reply_lower = reply.lower()
    forbidden = [f.strip().lower() for f in must_not_include_str.split(';') if f.strip()]
    violations = [f for f in forbidden if f in reply_lower]
    return len(violations) == 0, violations

def run_conversation_eval(
    csv_path: str = "Capstone_Project_Dataset_FTTT_2026/practice/conversations.csv",
    output_json: str = "sample_outputs/step3_conversations_eval.json"
):
    df = pd.read_csv(csv_path, dtype=str)
    agent = SupportAgent()
    
    total_turns = len(df)
    decision_correct = 0
    tools_correct = 0
    must_include_correct = 0
    must_not_violations = 0
    
    conversations_grouped = df.groupby('conversation_id', sort=False)
    results = []
    
    for cid, turns in conversations_grouped:
        agent.reset(conversation_id=cid)
        conv_results = []
        
        for idx, r in turns.iterrows():
            turn_num = int(r['turn'])
            customer_msg = r['customer_message']
            exp_dec = r['expected_decision']
            exp_tools = str(r['expected_tool_calls'])
            must_inc = str(r['must_include'])
            must_not = str(r['must_not_include'])
            scenario = r['scenario']
            
            res = agent.respond(customer_msg)
            reply = res['reply']
            actual_dec = res['decision']
            actual_tools = res['tool_calls']
            
            # 1. Decision check
            dec_ok = actual_dec == exp_dec
            if dec_ok:
                decision_correct += 1
                
            # 2. Tool call check
            if exp_tools == 'nan' or not exp_tools.strip():
                tool_ok = len(actual_tools) == 0
            else:
                # E.g. lookup_order(order_id=89782837) or create_ticket()
                tool_ok = False
                for at in actual_tools:
                    if 'create_ticket' in exp_tools and 'create_ticket' in at:
                        tool_ok = True
                    elif 'verification_value' in exp_tools:
                        if 'verification_value' in at:
                            tool_ok = True
                    elif 'lookup_order' in exp_tools and 'verification_value' not in exp_tools:
                        if 'lookup_order' in at and 'verification_value' not in at:
                            tool_ok = True
            if tool_ok:
                tools_correct += 1
                
            # 3. Must include check
            inc_ok = evaluate_must_include(reply, must_inc)
            if inc_ok:
                must_include_correct += 1
                
            # 4. Must not include check
            not_ok, viols = evaluate_must_not_include(reply, must_not)
            if not not_ok:
                must_not_violations += 1
                
            conv_results.append({
                'turn': turn_num,
                'customer_message': customer_msg,
                'expected_decision': exp_dec,
                'actual_decision': actual_dec,
                'decision_passed': dec_ok,
                'expected_tools': exp_tools,
                'actual_tools': actual_tools,
                'tools_passed': tool_ok,
                'must_include_passed': inc_ok,
                'must_not_violations': viols,
                'agent_reply': reply
            })
            
        results.append({
            'conversation_id': cid,
            'scenario': turns.iloc[0]['scenario'],
            'total_turns': len(turns),
            'turns': conv_results
        })
        
    summary = {
        'total_conversations': len(conversations_grouped),
        'total_turns': total_turns,
        'decision_accuracy': f"{decision_correct}/{total_turns} ({decision_correct/total_turns*100:.1f}%)",
        'tool_calling_accuracy': f"{tools_correct}/{total_turns} ({tools_correct/total_turns*100:.1f}%)",
        'must_include_accuracy': f"{must_include_correct}/{total_turns} ({must_include_correct/total_turns*100:.1f}%)",
        'hallucination_violations': must_not_violations
    }
    
    os.makedirs(os.path.dirname(output_json), exist_ok=True)
    with open(output_json, 'w', encoding='utf-8') as f:
        json.dump({'summary': summary, 'conversations': results}, f, indent=2, ensure_ascii=False)
        
    print("=" * 65)
    print("VOICEOPS 2026: STEP 3 (CONVERSATIONS & TOOLS) EVALUATION")
    print("=" * 65)
    print(f"Total Conversations: {len(conversations_grouped)} | Total Turns: {total_turns}")
    print("-" * 65)
    print(f"Decision Accuracy        : {summary['decision_accuracy']}")
    print(f"Tool Calling Accuracy    : {summary['tool_calling_accuracy']}")
    print(f"Fact Coverage (must_inc) : {summary['must_include_accuracy']}")
    print(f"Hallucination Violations : {summary['hallucination_violations']}")
    print("=" * 65)
    print(f"Detailed turn-by-turn log saved to: {output_json}")

if __name__ == '__main__':
    run_conversation_eval()
